<!-- Main Content -->
<section class="grid-area">
  <div class="grid-item1-4 img-center">
    <img class="img-logo" src="/media/Logo.png" alt="Logo">
  </div> <!-- .grid-item1-4 -->
  <div class="überschrift-container">
    <p class="überschrift-shadow">Corporate Design</p> 
    <p class="überschrift">Corporate Design</p> 
  </div>
  <div class="grid-item1-4" style="margin: 0 auto;">
    <div class="book">
      <div id="pages" class="pages">
        <div class="page"> <img src="/media/CDM1.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM2.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM3.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM4.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM5.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM6.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM7.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM8.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM9.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM10.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM11.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM12.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM13.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM14.jpg" alt=""> </div>
        <div class="page"> <img src="/media/CDM15.jpg" alt=""> </div>
      </div>
    </div>
  </div> <!-- .grid-item1-4 -->
  <div class="grid-item1-2 img-center" >
    <p class="überschrift-shadow">Rotwein</p> 
    <p class="überschrift">Rotwein</p> 
    <img class="img-wein" src="/media/Rot.jpg" alt="Rotwein">
  </div> <!-- .grid-item1-2 -->
  <div class="grid-item2-3 img-center">
    <p class="überschrift-shadow">Weißwein</p> 
    <p class="überschrift">Weißwein</p> 
    <img class="img-wein" src="/media/Weiss.jpg" alt="Weißwein">
  </div> <!-- .grid-item2-3 -->
  <div class="grid-item3-4 img-center">
    <p class="überschrift-shadow">Premiumwein</p> 
    <p class="überschrift">Premiumwein</p> 
    <img class="img-wein" src="/media/Premium.jpg" alt="Premiumwein">
  </div> <!-- .grid-item3-4 -->
  <div class="überschrift-container">
    <p class="überschrift-shadow">Visitenkarte</p> 
    <p class="überschrift">Visitenkarte</p> 
  </div>
  <div class="grid-item1-4"> 
    <p class="visitenkarte-text">Die Kommunikation ist ein wichtiger Bestandteil in der Interaktion mit dem Kunden. Wichtige Bestandteile sind da die Visitenkarte und der Briefbogen.</p>
  </div> <!-- .grid-item1-2 -->
  <div class="grid-item1-4 img-center">
    <img class="img-visitenkarte" src="/media/VisitenkarteVorderseite.png" alt="Visitenkarte">
  </div> <!-- .grid-item2-3 -->
  <div class="grid-item1-4 img-center">
    <img class="img-visitenkarte" src="/media/VisitenkarteRueckseite.png" alt="Visitenkarte">
  </div> <!-- .grid-item3-4 -->
  <div class="überschrift-container">
    <p class="überschrift-shadow">Briefbogen</p> 
    <p class="überschrift">Briefbogen</p> 
  </div>
  <div class="grid-item1-4 img-center">
    <img class="img-briefbogen"  src="/media/BriefbogenVorderseite.png" alt="Briefbogen">
  </div> <!-- .grid-item2-3 -->
  <div class="grid-item1-4 img-center">
    <img class="img-briefbogen"  src="/media/BriefbogenRueckseite.png" alt="Briefbogen">
  </div> <!-- .grid-item3-4 -->
</section> <!-- .grid-area -->