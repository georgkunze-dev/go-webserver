<!-- Main Content -->
<section class="grid-area">
  <!-- Plakat 1  -->
  <div class="überschrift-container">
    <p class="überschrift-shadow">Abstraktes-Filmplakat</p> 
    <p class="überschrift">Abstraktes-Filmplakat</p>
  </div>
  <div class="grid-item1-2" style="text-align: center;">
    <img class="img-plakat" src="/media/Filmplakat1.jpg" alt="Filmplakat 1">
  </div> <!-- .grid-item1-2 -->
  <div class="grid-item2-4">
    <p class="text plakat1-text">
      Bei dem ersten Plakat handelt es sich um ein abstraktes Filmplakat von dem Film "Le Mans 66 – Gegen jede Chance" (Originaltitel: Ford v Ferrari). <br>
      Ziel war es, den Inhalt des Filmes auf eine abstrakte Weise zu Charakterisieren und abzubilden. <br>
      Dabei steht der helle Blauton symbolisch für den Rennsieger Ford im Vordergrund.
    </p>
  </div> <!-- .grid-item2-4 -->
  <!-- Plakat 2  -->
  <div class="überschrift-container">
    <p class="überschrift-shadow">Filmszene-Filmplakat</p> 
    <p class="überschrift">Filmszene-Filmplakat</p>
  </div>
  <div class="grid-item1-2" style="text-align: center;">
    <img class="img-plakat" src="/media/Filmplakat2.jpg" alt="Filmplakat 2">
  </div> <!-- .grid-item1-2 -->
  <div class="grid-item2-4">
    <p class="text plakat2-text">
      Bei dem zweiten Plakat handelt es sich Ebenfals um ein Filmplakat über den Film "Le Mans 66". <br> 
      Im zweiten Plakat wird eine Szene aus dem Film als Hintergrund verwendet, auf dem der Hauptcharakter Ken Miles, gespielt von Christian Bale, abgebildet ist.
    </p>
  </div> <!-- .grid-item2-4 -->
  <!-- Plakat 3  -->
  <div class="überschrift-container">
    <p class="überschrift-shadow">Zitat-Plakat</p> 
    <p class="überschrift">Zitat-Plakat</p>
  </div>
  <div class="grid-item1-2" style="text-align: center;">
    <img class="img-plakat" src="/media/Zitatplakat.jpg" alt="Zitatplakat">
  </div> <!-- .grid-item1-2 -->
  <div class="grid-item2-4">
    <p class="text plakat3-text">
      Beim dritten Plakat handelt es sich um ein Zitat-Plakat. <br>
      Auf dem Plakat ist das Zitat von Ludwig Mies van der Rohe "Weniger ist mehr" abgebildet. <br>
      Die Aspekte von "Weniger ist mehr" sind dabei auf dem gesamten Plakat, wie zum Beispiel dem Dreieck, der Schrift oder dem Plakat an sich zu finden.
    </p>
  </div> <!-- .grid-item2-4 -->
</section> <!-- .grid-area -->