<!-- Main Content -->
<div class="gallery">
  <section class="grid-area">
    <div class="grid-item1-2">
      <img src="/media/G1.jpg" alt="Gallery-image1">
    </div> <!-- .grid-item1-2 -->
    <div class="grid-item2-3">
      <img src="/media/G2.jpg" alt="Gallery-image2">
    </div> <!-- .grid-item2-3 -->
    <div class="grid-item3-4">
      <img src="/media/G3.jpg" alt="Gallery-image3">
    </div> <!-- .grid-item3-4 -->
    <div class="grid-item1-2">
      <img src="/media/G4.jpg" alt="Gallery-image4">
    </div> <!-- .grid-item1-2 -->
    <div class="grid-item2-3">
      <img src="/media/G5.jpg" alt="Gallery-image5">
    </div> <!-- .grid-item2-3 -->
    <div class="grid-item3-4">
      <img src="/media/G6.jpg" alt="Gallery-image6">
    </div> <!-- .grid-item3-4 -->
    <div class="grid-item1-2">
      <img src="/media/G7.jpg" alt="Gallery-image7">
    </div> <!-- .grid-item1-2 -->
    <div class="grid-item2-3">
      <img src="/media/G8.jpg" alt="Gallery-image8">
    </div> <!-- .grid-item2-3 -->
    <div class="grid-item3-4">
      <img src="/media/G9.jpg" alt="Gallery-image9">
    </div> <!-- .grid-item3-4 -->
  </section> <!-- .grid-areea -->   
</div>