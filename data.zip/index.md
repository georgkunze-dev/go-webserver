<!-- Start Banner -->
<div class="background" style="background-image: url(/media/woodbackground.jpeg);"> 
  <div class="title-background">
    <p class="titel">Georg Kunze</p>
    <div class="linie"></div>
    <p class="untertitel">Medieninformatikstudent</p>
  </div>        
</div>
<!-- Main Content -->
<section class="grid-area" style="margin-top: 100vh;">
  <div class="überschrift-container">
    <p class="überschrift-shadow">Über mich</p> 
    <p class="überschrift">Über mich</p>
  </div>
  <div class="grid-item1-2" style="text-align: center;"> <!-- Die Zahlen hinter dem "grid-item" bedeuten den grid-column-start und grid-column-end. In dem Fall grid-column-start: 1; grid-column-end: 2; -->
    <img class="img-portrait" src="/media/Portrait.jpg" alt="Georg Kunze">
  </div> <!-- .grid-item1-2 -->
  <div class="grid-item2-4" style="margin: 0 auto;">
    <ul class="info">
      <li><p>➝<span style="font-weight: bold;">Name:</span> Georg Kunze</p></li>
      <li><p>➝ <span style="font-weight: bold;">Website:</span> www.example.de</p></li>
      <li><p>➝ <span style="font-weight: bold;">Telefon:</span> 01234 5678910</p></li>
      <li><p>➝ <span style="font-weight: bold;">Wohnort:</span> Wernigerode</p></li>
      <li><p>➝ <span style="font-weight: bold;">Alter:</span> 20</p></li>
      <li><p>➝ <span style="font-weight: bold;">Abschluss:</span> Abitur</p></li>
      <li><p>➝ <span style="font-weight: bold;">E-mail:</span> u36363@hs-harz.de</p></li>
      <li><p>➝ <span style="font-weight: bold;">Studienstandort:</span> Wernigerode</p></li>
    </ul>
  </div> <!-- .grid-item2-4 -->
  <div class="grid-item1-4">
    <p class="text">
      Mein Name ist Georg Kunze. Ich studiere aktuell Medieninformatik im zweiten Semester an der Hochschule Harz für angewandte Wissenschaften in Wernigerode. <br> <br>
    </p>
    <div class="video-map-wrapper">
      <p>Studiengang Medieninformatik:</p>
      <iframe class="yt-video" src="https://www.youtube.com/embed/O1uOU8YDivQ"></iframe>
      <p>Standort der Hochschule Harz:</p>
      <div id="mapdiv"></div>
    </div>
    <p class="text">
      Mein Abitur habe ich in Halberstadt an dem Käthe-Kollwitz-Gymnasium gemacht. Vor dem Medieninformatikstudium habe ich das zwei Semester lange Orientierungsstudium ebenfals an der Hochschule Harz abgeschlossen. <br> <br>
      Auf den nachfolgenden Seiten präsentiere ich Arbeiten, die während des ersten Semesters meines Studiums entstanden sind.
    </p>
  </div> <!-- .grid-item1-4 -->
</section> <!-- .grid-area -->