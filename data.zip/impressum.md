<section class="grid-area">
  <div class="überschrift-container">
    <p class="überschrift-shadow">Impressum</p> 
    <p class="überschrift">Impressum</p> 
  </div>
  <div class="grid-item1-4">
    <p style="margin: 100px;">
        Angaben gemäß § 5 TMG <br>
        Georg Kunze<br> 
        Musterstraße 1<br> 
        12345 Musterstadt <br> <br>
        <strong>Vertreten durch: </strong><br>
        Georg Kunze <br> <br>
        <strong>Kontakt:</strong> <br>
        Telefon: 01234 567890<br>
        E-Mail: u36363@hs-harz.de</a> </br> <br> <br>
        <strong>Haftungsausschluss: </strong> <br><br>
        <strong>Haftung für Inhalte</strong> <br>
        Die Inhalte unserer Seiten wurden mit größter Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und
        Aktualität der Inhalte können wir jedoch keine Gewähr übernehmen. Als Diensteanbieter sind wir gemäß 
        § 7 Abs.1 TMG für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Nach §§ 8 
        bis 10 TMG sind wir als Diensteanbieter jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde
        Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.
        Verpflichtungen zur Entfernung oder Sperrung der Nutzung von Informationen nach den allgemeinen Gesetzen
        bleiben hiervon unberührt. Eine diesbezügliche Haftung ist jedoch erst ab dem Zeitpunkt der Kenntnis einer
        konkreten Rechtsverletzung möglich. Bei Bekanntwerden von entsprechenden Rechtsverletzungen werden wir diese
        Inhalte umgehend entfernen. <br><br>
        <strong>Haftung für Links</strong><br>
        Unser Angebot enthält Links zu externen Webseiten Dritter, auf deren Inhalte wir keinen Einfluss haben.
        Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten
        Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich. Die verlinkten Seiten wurden
        zum Zeitpunkt der Verlinkung auf mögliche Rechtsverstöße überprüft. Rechtswidrige Inhalte waren zum Zeitpunkt
        der Verlinkung nicht erkennbar. Eine permanente inhaltliche Kontrolle der verlinkten Seiten ist jedoch ohne
        konkrete Anhaltspunkte einer Rechtsverletzung nicht zumutbar. Bei Bekanntwerden von Rechtsverletzungen werden 
        wir derartige Links umgehend entfernen.
    </p>
  </div> <!-- .grid-item1-4 -->
</section> <!-- grid-area -->