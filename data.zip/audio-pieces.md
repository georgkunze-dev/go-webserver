<!-- Main Content -->
<section class="grid-area">
  <div class="überschrift-container">
    <p class="überschrift-shadow">Türstück</p> 
    <p class="überschrift">Türstück</p> 
  </div>
  <div class="grid-item1-4" style="text-align: center;">
    <img class="img-audio" src="/media/Tuerstueck.jpg" alt="Türstück">
  </div> <!-- .grid-item1-4 -->
  <div class="grid-item1-4" style="text-align: center;">
    <audio controls src="/media/tuerstueck.wav"></audio>
  </div> <!-- .grid-item1-4 -->
  <div class="grid-item1-4">
    <p class="text audio-text">
      Das Audiostück "Türstück" besteht nur aus Sounds, welche von Türen kommen oder mit Türen gemacht wurden. (Unter der Kategorie Tür zählt zum Beispiel auch Mikrowellen- oder Ofentüren) <br>
      Bei diesem Audiostück wird eine Geschichte einer Person erzählt, die zuerst einen Aufzug benutzt. Anschließend geht sie zu einer Tür und klopft dort an. Die Tür geht auf, die Person geht hinein und die Tür schließt sich wieder. 
      Dann wiederhohlen sich Sounds aus Türöffnungen und -schließungen sowie klopfen. Das Audiostück endet so wie es begonnen hat, mit dem Fahrstuhl. 
    </p>
  </div> <!-- .grid-item1-4 -->
  <div class="überschrift-container">
    <p class="überschrift-shadow">Gedicht</p> 
    <p class="überschrift">Gedicht</p> 
  </div>
  <div class="grid-item1-4" style="text-align: center;">
    <img class="img-audio" src="/media/Gedicht.jpg" alt="Gedicht">
  </div> <!-- .grid-item1-4 -->
  <div class="grid-item1-4" style="text-align: center;">
    <audio controls src="/media/gedicht.wav"></audio>
  </div> <!-- .grid-item1-4 -->
  <div class="grid-item1-4">
    <p class="text audio-text">
      Das zweite Audiostück erzählt das Gedicht "Kleines Sommerlied" von Wolfgang Herrndorf. <br>
      Dabei wurde der Text selbst eingesprochen. Anschließend wurde der Text mit diversen Soundeffekten abgerundet und immersiver für den Zuhörer gemacht, damit er sich besser in das Geschehen hineinversetzen kann.
    </p>
  </div> <!-- .grid-item1-4 -->
  <div class="überschrift-container">
    <p class="überschrift-shadow">Podcast</p> 
    <p class="überschrift">Podcast</p> 
  </div>
  <div class="grid-item1-4" style="text-align: center;">
    <img class="img-audio" src="/media/Podcast.jpg" alt="Podcast">
  </div> <!-- .grid-item1-4 -->
  <div class="grid-item1-4" style="text-align: center;">
    <audio controls src="/media/podcast.wav"></audio>
  </div> <!-- .grid-item1-4 -->
  <div class="grid-item1-4">
    <p class="text audio-text">
      Das dritte Audiostück ist ein Interview in Form eines Podcast. Dieser Podcast handelt von Filmmusik, speziell die Stimmung, die sie vermittelt.
      Des Weiteren konzentriert sich der Podcast auf die Filmmusik aus den Star Wars Filmen, komponiert von John Williams.
    </p>
  </div> <!-- .grid-item1-4 -->
</section> <!-- .grid-area -->